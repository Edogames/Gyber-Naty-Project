

<?php $__env->startSection('title', 'Something went wrong.'); ?>

<?php $__env->startSection('btn'); ?>
    <h2 id="header-txt" style="color: #533278;">The Macroeconomic DAO</h2>

    <a href="<?php echo e(URL::route('home')); ?>" class="btn">Home</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" id="card">
        <div class="d-flex">
            <h3 style="text-align: center">Something went wrong.<br>Please try again</h3>
        </div>
        <a href="<?php echo e(URL::route('sale')); ?>" class="glow-on-hover" style="margin-bottom: 0;">Private Sale</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    let link = location.href
    let splited = link.split('/send');
    if (link.indexOf('/send') > -1){
        location.href = `${splited[0]}/fail`;
    }
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs 2\resources\views/fail.blade.php ENDPATH**/ ?>