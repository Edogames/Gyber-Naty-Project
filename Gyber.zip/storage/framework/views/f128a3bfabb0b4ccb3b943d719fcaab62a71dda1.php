<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" onmousemove="getMousePose(event)">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <link href="<?php echo e(asset('styles/style.css')); ?>" rel="stylesheet">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <header>
            <div class="container">
                <div class="d-flex space-between">
                    <a class="logo" href="<?php echo e(URL::route('home')); ?>">
                        <div class="d-flex">
                            <img style="cursor: pointer;" class="main-logo" src="<?php echo e(asset('images/logo.svg')); ?>" alt="">
                            <h2>Gyber.org</h2>
                        </div>
                    </a>
                    <?php echo $__env->yieldContent('btn'); ?>
                </div>
            </div>
            
        </header>
        <div class="wrapper">
            <div class="container">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <footer>
                <hr>
                <div id="footer">
                    <br>
                    <div class="d-flex" id="footer-logo">
                        <img src="<?php echo e(asset('images/by.png')); ?>">
                        <h2>Gybernaty</h2>
                    </div>
                    <div class="icons">
                        <a href="http://" target="_blank" style="width: fit-content; height: fit-content;" rel="noopener noreferrer"><img class="icon" src="<?php echo e(asset('images/icons/reddit_icon.png')); ?>"></a>
                        <a href="http://" target="_blank" style="width: fit-content; height: fit-content;" rel="noopener noreferrer"><img class="icon" src="<?php echo e(asset('images/icons/medium_icon.png')); ?>"></a>
                        <a href="http://" target="_blank" style="width: fit-content; height: fit-content;" rel="noopener noreferrer"><img class="icon" src="<?php echo e(asset('images/icons/linked_icon.png')); ?>"></a>
                        <a href="http://" target="_blank" style="width: fit-content; height: fit-content;" rel="noopener noreferrer"><img class="icon" src="<?php echo e(asset('images/icons/github_icon.png')); ?>"></a>
                        <a href="http://" target="_blank" style="width: fit-content; height: fit-content;" rel="noopener noreferrer"><img class="icon" src="<?php echo e(asset('images/icons/twitter_icon.png')); ?>"></a>
                        <a href="http://" target="_blank" style="width: fit-content; height: fit-content;" rel="noopener noreferrer"><img class="icon" src="<?php echo e(asset('images/icons/discord_icon.png')); ?>"></a>
                    </div>
                    <br>
                </div>
                <hr>
            </footer>
        </div>

        <script src="<?php echo e(asset('script.js')); ?>"></script>
        <script>
            <?php echo $__env->yieldContent('js'); ?>
        </script>
    </body>
    </div>
    <div id="area">
        <ul class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
        <div class='light x2'></div>
        <div class='light x3'></div>
        <div class='light x4'></div>
        <div class='light x7'></div>
    </div>
</html>
<?php /**PATH C:\xampp\htdocs\resources\views/layouts/main.blade.php ENDPATH**/ ?>