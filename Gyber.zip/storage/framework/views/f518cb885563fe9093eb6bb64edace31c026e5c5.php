<?php $__env->startSection('title', 'home'); ?>

<?php $__env->startSection('btn'); ?>
    <th>
        <a href="<?php echo e(asset('pdf/info.pdf')); ?>" target="_blank">
            <h2 id="chosen">Lite Paper</h2>
        </a>
    </th>
    <th>
        <a href="<?php echo e(URL::route('sale')); ?>" class="btn">Private Sale</a>
    </th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="title" id="title">Welcome to the future</h1>
    <h1 class="subtitle" id="subtitle">The Macroeconomic DAO</h1>

    <a href="https://bscscan.com/token/0xEbaD243C0C12f61E980AAE7F694914dd21F7FF42" target="_blank" class="button glow-on-hover">Contract Adress</a>

    <div class="text">
        <h5>Millions of users can spend</h5>
        <h5>billions on their interests</h5>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    let link = location.href
    let splited = link.split('/send');
    if (link.indexOf('/send') > -1){
        location.href = splited[0];
    }
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs 2\resources\views/home.blade.php ENDPATH**/ ?>