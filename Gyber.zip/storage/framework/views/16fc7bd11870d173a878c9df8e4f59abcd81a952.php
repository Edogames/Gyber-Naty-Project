

<?php $__env->startSection('title', 'Private sales'); ?>

<?php $__env->startSection('btn'); ?>
    <th>
        <h2 id="header-txt" style="color: #533278;">The Macroeconomic DAO</h2>
    </th>

    <a href="<?php echo e(URL::route('home')); ?>" class="btn">Home</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" id="card">
        <h3 style="text-align: center">To participate in a private sale <br> fill out the following form:</h3>
        <br>
        <form action="<?php echo e(route('sale.send')); ?>" method="POST">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>
            <input class="input-field" required type="text" name="name" placeholder="Name or organization">
            <div id="price">
                <p style="color: #83A400;">minimum quantity</p>
                <p style="color: gray; font-style: italic;" id="second">$100 000</p>
            </div>
            <input class="input-field" required type="text" id="invest" name="invest" placeholder="Amount of investment">
            <p style="color: red" id="err"></p>
            <input type="email" required id="email" name="email" placeholder="Email">
            <button id="submit" type="submit">OK</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    let link = location.href
    let splited = link.split('/send');
    if (link.indexOf('/send') > -1){
        location.href = `${splited[0]}/sale`;
    }

    let text = document.getElementById('invest');
    let submit = document.getElementById('submit');
    let errMSG = document.getElementById("err");

    text.addEventListener('input', () => {
        let splited = text.value.split('$');
        let num = Number(splited[1]);
        if (splited[1] == undefined){
            text.value = `$ ${splited[0]}`;
        }else{
            if(num >= 100000){
                text.style.border = "1px solid #4A4A4A";
                errMSG.innerText = "";
                text.value = `$${splited[1]}`;
            }else{
                text.style.border = "1px solid red";
                errMSG.innerText = `You must type more that $100 000 ($${num} is typed).`;
                text.value = `$${splited[1]}`;
            }
        }
    });

    submit.addEventListener("click", (e) => {
        let splited = text.value.split('$');
        let num = Number(splited[1]);
        if(num < 100000){
            e.preventDefault();
        }
    });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs 2\resources\views/sale.blade.php ENDPATH**/ ?>